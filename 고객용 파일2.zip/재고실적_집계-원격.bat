@echo off
chcp 65001 >nul
setlocal
call "%~dp0_paths_remote.bat"
cd /d "%KK_ROOT%"

if not exist "%PY%" (
    echo Python 환경이 없습니다. setup_remote.bat 을 먼저 실행하세요.
    echo.
    call "%KK_ROOT%setup_remote.bat"
    if not exist "%PY%" (
        echo 설치 실패.
        pause
        exit /b 1
    )
)

echo Installing remote client dependencies...
"%PY%" -m pip install -q -r "%KK_ROOT%requirements-remote.txt"

set "HOST_IP="
for /f "tokens=2 delims='" %%H in ('findstr /C:"host:" "%KK_ROOT%config.yaml" 2^>nul') do set "HOST_IP=%%H"
set "HOST_IP=%HOST_IP: =%"
if "%HOST_IP%"=="" (
    set /p HOST_IP=브릿지 서버 IP (호스트 PC): 
)
if "%HOST_IP%"=="" (
    echo IP가 필요합니다.
    pause
    exit /b 1
)

echo.
echo ========================================
echo  ERP 원격 UI (고객 PC)
echo  서버: %HOST_IP%
echo ========================================
echo.

set "PYTHONUTF8=1"
"%PY%" -X utf8 "%KK_ROOT%auto_trader\remote_main.py" --host %HOST_IP%
set "ERR=%ERRORLEVEL%"
if not "%ERR%"=="0" pause
exit /b %ERR%
