"""Remote client entry: sync updates from host then launch Excel UI."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import auto_trader.qt_fix  # noqa: F401

from PyQt5.QtWidgets import QApplication, QMessageBox

from auto_trader import i18n_ko as T
from auto_trader.config import load_config
from auto_trader.excel_ui import run_excel_ui
from auto_trader.remote_sync import sync_from_host


def main() -> int:
    parser = argparse.ArgumentParser(description="Remote Excel UI client")
    parser.add_argument("--host", help="Bridge host IP")
    parser.add_argument("--port", type=int, default=0, help="Bridge WS port")
    parser.add_argument("--http-port", type=int, default=0, help="Bridge HTTP port")
    parser.add_argument("--no-sync", action="store_true", help="Skip auto-update")
    args = parser.parse_args()

    config = load_config()
    host = (args.host or config.bridge_host or "").strip()
    if not host:
        host = input("브릿지 서버 IP: ").strip()
    if not host:
        print("호스트 IP가 필요합니다.")
        return 1

    http_port = args.http_port or int(config.bridge_http_port or 0) or (int(config.bridge_port or 8765) + 1)
    base_url = f"http://{host}:{http_port}"

    if not args.no_sync and config.bridge_auto_sync:
        count, msg = sync_from_host(base_url, ROOT, token=config.bridge_token)
        app = QApplication.instance() or QApplication([])
        QMessageBox.information(None, T.MSG_ERP_TITLE, msg)
    else:
        app = QApplication.instance() or QApplication([])

    config.bridge_role = "client"
    config.bridge_host = host
    if args.port:
        config.bridge_port = args.port

    return run_excel_ui(config=config, remote=True)


if __name__ == "__main__":
    code = main()
    if code != 0:
        input("Press Enter to close...")
    raise SystemExit(code)
