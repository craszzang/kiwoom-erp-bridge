"""Pull project updates from host bridge HTTP server."""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path
from typing import Callable

import requests

from auto_trader.bridge_protocol import BRIDGE_VERSION

logger = logging.getLogger(__name__)


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _manifest_cache_path(root: Path) -> Path:
    return root / ".bridge_sync_manifest.json"


def sync_from_host(
    base_url: str,
    root: Path,
    *,
    token: str = "",
    timeout: float = 8.0,
    on_progress: Callable[[str], None] | None = None,
) -> tuple[int, str]:
    """Download changed files. Returns (updated_count, message)."""
    headers = {"X-Bridge-Token": token} if token else {}

    def _progress(msg: str) -> None:
        logger.info(msg)
        if on_progress is not None:
            on_progress(msg)

    url = f"{base_url.rstrip('/')}/api/sync/manifest"
    try:
        _progress(f"호스트 연결 중...\n{url}")
        resp = requests.get(url, headers=headers, timeout=timeout)
        resp.raise_for_status()
    except Exception as exc:
        return 0, f"동기화 실패 (호스트 연결): {exc}\n\nF5로 연결은 시도할 수 있습니다."

    remote = resp.json()
    if remote.get("bridge_version") != BRIDGE_VERSION:
        logger.warning(
            "bridge version mismatch host=%s client=%s",
            remote.get("bridge_version"),
            BRIDGE_VERSION,
        )

    files: dict[str, dict] = remote.get("files") or {}
    cache_path = _manifest_cache_path(root)
    local_cache: dict[str, str] = {}
    if cache_path.is_file():
        try:
            local_cache = json.loads(cache_path.read_text(encoding="utf-8"))
        except Exception:
            local_cache = {}

    updated = 0
    for rel, meta in files.items():
        rel_path = rel.replace("/", "\\") if "\\" in str(root) else rel
        dest = root / rel_path
        remote_hash = str(meta.get("sha256", ""))
        if not remote_hash:
            continue
        if dest.is_file() and _sha256_file(dest) == remote_hash:
            local_cache[rel] = remote_hash
            continue
        if local_cache.get(rel) == remote_hash and dest.is_file():
            continue

        try:
            _progress(f"다운로드: {rel}")
            fr = requests.get(
                f"{base_url.rstrip('/')}/api/sync/file",
                params={"path": rel},
                headers=headers,
                timeout=timeout,
            )
            fr.raise_for_status()
        except Exception as exc:
            logger.warning("download failed %s: %s", rel, exc)
            continue

        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(fr.content)
        local_cache[rel] = remote_hash
        updated += 1
        logger.info("synced %s", rel)

    cache_path.write_text(json.dumps(local_cache, ensure_ascii=False, indent=2), encoding="utf-8")
    if updated:
        return updated, f"업데이트 {updated}개 파일 적용 (v{remote.get('bundle_version', '?')})"
    return 0, f"최신 버전입니다 (v{remote.get('bundle_version', '?')})"
